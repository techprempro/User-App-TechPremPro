package com.earnkori.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout

/**
 * EarnKori - a thin WebView shell that opens ONLY https://techprempro.com/earnkori.
 * Any other address (task links, social sites, etc.) is handed to the phone's browser.
 */
class MainActivity : Activity() {

    companion object {
        private const val START_URL = "https://techprempro.com/earnkori"
        private const val HOST = "techprempro.com"
        private const val FILE_CHOOSER_CODE = 1001

        // Paths that may stay inside the app. Everything else opens in the external browser.
        private val ALLOWED_PREFIXES = listOf("/earnkori", "/forgot-password", "/reset-password", "/email/verify")
    }

    private lateinit var webView: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var failed = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setBackgroundColor(Color.parseColor("#0F172A"))
            visibility = View.INVISIBLE            // the splash logo stays visible until the first page is ready
        }
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setSupportZoom(false)
            builtInZoomControls = false
            textZoom = 100
            loadWithOverviewMode = true
            useWideViewPort = true
            mediaPlaybackRequiresUserGesture = true
            userAgentString = userAgentString + " EarnKoriApp/1.0"
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, false)
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                if (isInternal(uri)) return false
                openExternally(uri)
                return true
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                if (url != null && url.startsWith("http")) failed = false   // a real page is loading again
            }

            override fun onPageFinished(view: WebView, url: String?) {
                if (!failed) webView.visibility = View.VISIBLE
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) {
                    failed = true
                    view.loadDataWithBaseURL(null, offlineHtml(), "text/html", "UTF-8", null)
                    view.visibility = View.VISIBLE
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            // Lets users pick screenshots for task proof.
            override fun onShowFileChooser(
                view: WebView, callback: ValueCallback<Array<Uri>>, params: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    startActivityForResult(params.createIntent(), FILE_CHOOSER_CODE)
                    true
                } catch (e: ActivityNotFoundException) {
                    fileCallback = null
                    false
                }
            }
        }

        if (savedInstanceState != null) webView.restoreState(savedInstanceState)
        else webView.loadUrl(START_URL)
    }

    private fun isInternal(uri: Uri): Boolean {
        if (uri.scheme != "https" || uri.host != HOST) return false
        val path = uri.path ?: "/"
        return ALLOWED_PREFIXES.any { path == it || path.startsWith("$it/") }
    }

    private fun openExternally(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE))
        } catch (_: ActivityNotFoundException) {
        }
    }

    // Retry button on the offline page calls this through a normal link to START_URL.
    private fun offlineHtml(): String = """
        <html><head><meta name='viewport' content='width=device-width,initial-scale=1'>
        <style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#0f172a;color:#fff;font-family:sans-serif;text-align:center;padding:24px}
        h2{margin:0 0 8px}p{color:#94a3b8;margin:0 0 22px}a{background:#10b981;color:#052e22;font-weight:700;text-decoration:none;padding:13px 28px;border-radius:12px;display:inline-block}</style></head>
        <body><div><h2>ইন্টারনেট সংযোগ নেই</h2><p>No internet connection. Please check your network.</p>
        <a href='$START_URL'>আবার চেষ্টা করুন / Retry</a></div></body></html>
    """.trimIndent()

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == FILE_CHOOSER_CODE) {
            fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCallback = null
        } else {
            @Suppress("DEPRECATION") super.onActivityResult(requestCode, resultCode, data)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (failed) {
            failed = false
            webView.loadUrl(START_URL)
        } else if (webView.canGoBack()) {
            webView.goBack()
        } else {
            @Suppress("DEPRECATION") super.onBackPressed()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onPause() { super.onPause(); CookieManager.getInstance().flush() }

    override fun onDestroy() {
        webView.stopLoading()
        (webView.parent as? ViewGroup)?.removeView(webView)
        webView.destroy()
        super.onDestroy()
    }
}
