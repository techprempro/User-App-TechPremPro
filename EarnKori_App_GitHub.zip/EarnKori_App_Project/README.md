# EarnKori Android App (WebView)

Opens only `https://techprempro.com/earnkori`. Other links (task links, social sites) open in the phone's browser.

* Package: `com.earnkori.app`  ·  name: EarnKori  ·  min Android 7.0 (API 24)
* Screenshot upload works (file chooser), login cookies are kept, back button navigates inside the app.
* Offline page with a Retry button; splash screen with the EarnKori logo.
* `PLAY_STORE_ICON_1024.png` is a 1024px icon for Play Store listings.

Build: upload `EarnKori_App_GitHub.zip` to the repo root together with `.github/workflows/build-earnkori-apk.yml`, then run the workflow.
It needs the same four secrets as the weather app: ANDROID_KEYSTORE_BASE64, ANDROID_KEYSTORE_PASSWORD, ANDROID_KEY_ALIAS, ANDROID_KEY_PASSWORD.
