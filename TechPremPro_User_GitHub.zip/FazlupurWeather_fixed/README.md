# Fazlupur Weather WebView

Google Search results for weather in Fazlupur, Fulchhari, Gaibandha. No separate weather API key.

Features: Bangla/English Google Search language toggle, refresh, offline retry, phone Back navigation.

## Build APK with GitHub Actions
1. Create a GitHub repository.
2. Upload the CONTENTS of this folder to the repository root.
3. Push to `main` or open Actions and run `Build Fazlupur Weather APK`.
4. Download artifact `Fazlupur-Weather-debug-apk` from the completed workflow run.
5. Extract the artifact ZIP and install `app-debug.apk`.

Google controls its search result layout and availability. This is not an official Google Weather API; local results may represent a nearby area. Internet is required.
