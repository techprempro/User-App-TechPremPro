package com.fazlupur.weather
import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.*
import android.widget.*
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

class MainActivity : Activity() {
 private lateinit var web: WebView
 private lateinit var offline: LinearLayout
 private var language = "bn"
 private fun isOnline(): Boolean {
  val cm=getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
  val n=cm.activeNetwork ?: return false
  val c=cm.getNetworkCapabilities(n) ?: return false
  return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
 }
 private fun loadWeather() {
  if (!isOnline()) { web.visibility=View.GONE; offline.visibility=View.VISIBLE; return }
  offline.visibility=View.GONE; web.visibility=View.VISIBLE
  val q=java.net.URLEncoder.encode("weather Fazlupur Fulchhari Gaibandha","UTF-8")
  web.loadUrl("https://www.google.com/search?q=$q&hl=$language")
 }
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val page=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(12,25,48)) }
  val bar=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(6,4,6,4); setBackgroundColor(Color.rgb(19,39,70)) }
  val title=TextView(this).apply { text="🌤 ফজলুপুর আবহাওয়া"; textSize=17f; setTextColor(Color.WHITE); setPadding(8,8,4,8) }
  val lang=Button(this).apply { text="EN"; setOnClickListener { language=if(language=="bn") "en" else "bn"; text=if(language=="bn") "EN" else "বাংলা"; loadWeather() } }
  val refresh=Button(this).apply { text="↻"; setOnClickListener { loadWeather() } }
  bar.addView(title,LinearLayout.LayoutParams(0,-2,1f)); bar.addView(lang); bar.addView(refresh); page.addView(bar)
  web=WebView(this).apply {
   settings.javaScriptEnabled=true; settings.domStorageEnabled=true; settings.loadsImagesAutomatically=true
   webViewClient=object:WebViewClient() {
    override fun onReceivedError(v:WebView?, req:WebResourceRequest?, err:WebResourceError?) {
     if(req?.isForMainFrame==true) { web.visibility=View.GONE; offline.visibility=View.VISIBLE }
    }
   }
   webChromeClient=WebChromeClient()
  }
  page.addView(web,LinearLayout.LayoutParams(-1,0,1f))
  offline=LinearLayout(this).apply {
   orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(20,20,20,20); visibility=View.GONE
   addView(TextView(this@MainActivity).apply { text="ইন্টারনেট সংযোগ নেই।\nNo internet connection."; textSize=18f; gravity=Gravity.CENTER; setTextColor(Color.WHITE) })
   addView(Button(this@MainActivity).apply { text="আবার চেষ্টা করুন / Retry"; setOnClickListener { loadWeather() } })
  }
  page.addView(offline,LinearLayout.LayoutParams(-1,0,1f)); setContentView(page)
  if(savedInstanceState==null) loadWeather()
 }
 @Deprecated("Deprecated in Java") override fun onBackPressed() { if(::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed() }
 override fun onDestroy() { if(::web.isInitialized) web.destroy(); super.onDestroy() }
}
