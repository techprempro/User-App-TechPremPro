# ফজলুপুরের আবহাওয়া

Modern Premium Android WebView weather app for Fazlupur, Fulchhari, Gaibandha.

## Features
- Open-Meteo forecast API (no API key required for normal non-commercial use; check provider terms for your use case)
- Bengali / English toggle
- Current conditions, feels-like temperature, hourly forecast and 7-day forecast
- Wind, humidity, precipitation and UV index
- Refresh, retry, automatic refresh every 30 minutes
- Bottom advertising placeholder (not connected to an ad network)

## Build
GitHub Actions workflow builds a debug APK on push or manual dispatch.

## Advertising
The bottom AD strip is a reserved placeholder. To serve real paid ads, create and approve an ad account and integrate a supported mobile ad SDK (for example Google AdMob) with your own App ID and Banner Ad Unit ID. Do not treat the placeholder as live advertising.

## Location note
The app attempts to resolve “Fazlupur” through Open-Meteo geocoding. If geocoding returns an unsuitable match, the fallback coordinates are approximate and should be replaced with verified coordinates for Fazlupur Union.
