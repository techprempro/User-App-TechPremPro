# ফজলুপুরের আবহাওয়া

Premium bilingual Android WebView weather app.

- Bangla and English interface
- Bangla (Bangladesh revised calendar) and English date display
- Current weather, hourly forecast, 7-day forecast
- Wind, humidity, precipitation, UV index
- Open-Meteo API
- App launcher icon and in-app weather logo
- Bottom ad placeholder reserved for your later ad code

## Ads
The bottom strip is only a placeholder. When you provide your approved ad network's code or SDK details, it can be integrated. Do not paste secret/private account credentials into a public repository.

## Build
Push to GitHub; Actions builds a debug APK. JVM target is Java/Kotlin 17.
