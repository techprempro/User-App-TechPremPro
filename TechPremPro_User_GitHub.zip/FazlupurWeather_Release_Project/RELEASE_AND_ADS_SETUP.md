# Fazlupur Weather — Signed Release APK and Adsterra

## Adsterra 320x50 banner
The 320x50 ad unit is displayed at its real 320x50 size. No cropping is applied. WebView JavaScript, DOM storage, first- and third-party cookies are enabled. Normal ad links and popup/new-window links are handed to the Android browser.

Ad clicks can still be blocked by Adsterra, invalid-traffic checks, an ad blocker, private DNS, a network filter, or an ad creative that is not clickable. Test using ordinary visitors and do not repeatedly click your own ads.

## One-time signing key setup
Create a private keystore on your own computer or trusted server. Keep the `.jks` file and passwords private and make a secure offline backup.

```bash
keytool -genkeypair -v -keystore fazlupur-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias fazlupur
base64 -w 0 fazlupur-release.jks
```

Add these GitHub repository Actions secrets:
- `ANDROID_KEYSTORE_BASE64` = complete output of the base64 command
- `ANDROID_KEYSTORE_PASSWORD` = keystore password
- `ANDROID_KEY_ALIAS` = `fazlupur` (or the alias you selected)
- `ANDROID_KEY_PASSWORD` = key password

Then run the workflow **Build Fazlupur Weather Signed Release APK**. It intentionally fails if signing secrets are missing; it will not create an unsigned release artifact.

Keep using the same keystore for every update. Losing it prevents in-place updates signed with the original key.

## Important
This project ZIP has not been compiled or security-scanned here. Play Protect may still warn about an APK installed outside Google Play; signing does not guarantee that the warning disappears.
