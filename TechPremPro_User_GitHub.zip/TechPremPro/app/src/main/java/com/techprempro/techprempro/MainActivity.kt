package com.techprempro.techprempro

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val baseUrl = "https://techprempro.com/api/v1"
    private var token = ""
    private var registerMode = false
    private lateinit var status: TextView
    private lateinit var name: EditText
    private lateinit var email: EditText
    private lateinit var password: EditText
    private lateinit var confirmPassword: EditText
    private lateinit var loginButton: Button
    private lateinit var registerButton: Button
    private lateinit var panel: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        name = findViewById(R.id.name)
        email = findViewById(R.id.email)
        password = findViewById(R.id.password)
        confirmPassword = findViewById(R.id.password_confirmation)
        loginButton = findViewById(R.id.login)
        registerButton = findViewById(R.id.register)
        panel = findViewById(R.id.panel)

        loginButton.setOnClickListener { login() }
        registerButton.setOnClickListener {
            if (registerMode) register() else setRegisterMode(true)
        }

        findViewById<Button>(R.id.dashboard).setOnClickListener { call("/dashboard") }
        findViewById<Button>(R.id.services).setOnClickListener { call("/services") }
        findViewById<Button>(R.id.orders).setOnClickListener { call("/orders") }
        findViewById<Button>(R.id.logout).setOnClickListener {
            token = ""
            panel.visibility = View.GONE
            setRegisterMode(false)
            status.text = "Logged out"
        }
    }

    private fun setRegisterMode(enabled: Boolean) {
        registerMode = enabled
        name.visibility = if (enabled) View.VISIBLE else View.GONE
        confirmPassword.visibility = if (enabled) View.VISIBLE else View.GONE
        loginButton.text = if (enabled) "BACK TO LOGIN" else "LOGIN"
        registerButton.text = if (enabled) "CREATE ACCOUNT" else "REGISTER"
        status.text = if (enabled) "Create your TechPremPro account" else "Enter your credentials"

        if (enabled) {
            loginButton.setOnClickListener { setRegisterMode(false) }
        } else {
            loginButton.setOnClickListener { login() }
        }
    }

    private fun login() {
        val e = email.text.toString().trim()
        val p = password.text.toString()
        if (e.isBlank() || p.isBlank()) {
            status.text = "Email and password are required"
            return
        }
        status.text = "Logging in..."
        thread {
            try {
                val body = JSONObject()
                    .put("email", e)
                    .put("password", p)
                    .put("device_name", "TechPremPro Android")
                val res = request("/login", "POST", body.toString(), false)
                val j = JSONObject(res.second)
                runOnUiThread {
                    if (res.first in 200..299 && j.has("token")) {
                        token = j.getString("token")
                        status.text = "Login successful"
                        panel.visibility = View.VISIBLE
                        call("/dashboard")
                    } else {
                        status.text = j.optString("message", "Login failed")
                    }
                }
            } catch (x: Exception) {
                runOnUiThread { status.text = x.message ?: "Network error" }
            }
        }
    }

    private fun register() {
        val n = name.text.toString().trim()
        val e = email.text.toString().trim()
        val p = password.text.toString()
        val cp = confirmPassword.text.toString()

        if (n.isBlank() || e.isBlank() || p.isBlank() || cp.isBlank()) {
            status.text = "All fields are required"
            return
        }
        if (p != cp) {
            status.text = "Passwords do not match"
            return
        }
        if (p.length < 8) {
            status.text = "Password must be at least 8 characters"
            return
        }

        status.text = "Creating account..."
        thread {
            try {
                val body = JSONObject()
                    .put("name", n)
                    .put("email", e)
                    .put("password", p)
                    .put("password_confirmation", cp)
                    .put("device_name", "TechPremPro Android")

                val res = request("/register", "POST", body.toString(), false)
                val j = JSONObject(res.second)

                runOnUiThread {
                    if (res.first in 200..299) {
                        if (j.has("token")) {
                            token = j.getString("token")
                            status.text = "Registration successful"
                            panel.visibility = View.VISIBLE
                            call("/dashboard")
                        } else {
                            setRegisterMode(false)
                            email.setText(e)
                            status.text = "Registration successful. Please login."
                        }
                    } else {
                        status.text = j.optString("message", "Registration failed")
                    }
                }
            } catch (x: Exception) {
                runOnUiThread { status.text = x.message ?: "Network error" }
            }
        }
    }

    private fun call(path: String) {
        status.text = "Loading..."
        thread {
            try {
                val r = request(path, "GET", null, true)
                runOnUiThread { status.text = r.second }
            } catch (x: Exception) {
                runOnUiThread { status.text = x.message ?: "Network error" }
            }
        }
    }

    private fun request(path: String, method: String, body: String?, auth: Boolean): Pair<Int, String> {
        val c = URL(baseUrl + path).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.setRequestProperty("Accept", "application/json")
        if (auth && token.isNotBlank()) c.setRequestProperty("Authorization", "Bearer $token")
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val stream = if (code >= 400) c.errorStream else c.inputStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        return code to text
    }
}
