package com.techprempro.techprempro

import android.app.Activity
import android.os.Bundle
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity: Activity(){
 private val baseUrl="https://techprempro.com/api/v1"
 private var token=""
 private lateinit var status:TextView
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main);status=findViewById(R.id.status);findViewById<Button>(R.id.login).setOnClickListener{login()};findViewById<Button>(R.id.dashboard).setOnClickListener{call("/dashboard")};findViewById<Button>(R.id.services).setOnClickListener{call("/services")};findViewById<Button>(R.id.orders).setOnClickListener{call("/orders")};findViewById<Button>(R.id.logout).setOnClickListener{token="";findViewById<LinearLayout>(R.id.panel).visibility=LinearLayout.GONE;status.text="Logged out"}}
 private fun login(){val e=findViewById<EditText>(R.id.email).text.toString();val p=findViewById<EditText>(R.id.password).text.toString();status.text="Logging in...";thread{try{val body=JSONObject().put("email",e).put("password",p).put("device_name","$com.techprempro.techprempro Android");val res=request("/login","POST",body.toString(),false);val j=JSONObject(res.second);if(res.first in 200..299){token=j.getString("token");runOnUiThread{status.text="Login successful";findViewById<LinearLayout>(R.id.panel).visibility=LinearLayout.VISIBLE;call("/dashboard")}}else runOnUiThread{status.text=j.optString("message","Login failed")}}catch(x:Exception){runOnUiThread{status.text=x.message?:"Network error"}}}}
 private fun call(path:String){status.text="Loading...";thread{try{val r=request(path,"GET",null,true);runOnUiThread{status.text=r.second}}catch(x:Exception){runOnUiThread{status.text=x.message?:"Network error"}}}}
 private fun request(path:String,method:String,body:String?,auth:Boolean):Pair<Int,String>{val c=URL(baseUrl+path).openConnection() as HttpURLConnection;c.requestMethod=method;c.connectTimeout=15000;c.readTimeout=20000;c.setRequestProperty("Accept","application/json");if(auth&&!token.isBlank())c.setRequestProperty("Authorization","Bearer $token");if(body!=null){c.doOutput=true;c.setRequestProperty("Content-Type","application/json");c.outputStream.use{it.write(body.toByteArray())}};val code=c.responseCode;val stream=if(code>=400)c.errorStream else c.inputStream;return code to stream.bufferedReader().use{it.readText()}}
}
