package com.techprempro.techprempro

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private val baseUrl = "https://techprempro.com/api/v1"
    private var token = ""
    private var registerMode = false

    private lateinit var status: TextView
    private lateinit var name: EditText
    private lateinit var email: EditText
    private lateinit var password: EditText
    private lateinit var confirmPassword: EditText
    private lateinit var loginButton: Button
    private lateinit var registerButton: Button
    private lateinit var panel: LinearLayout
    private lateinit var contentPanel: LinearLayout

    private lateinit var servicesPanel: LinearLayout
    private lateinit var categorySpinner: Spinner
    private lateinit var subcategorySpinner: Spinner
    private lateinit var serviceSearch: EditText
    private lateinit var serviceList: LinearLayout
    private lateinit var serviceCount: TextView
    private lateinit var nextServices: Button

    private data class Choice(val id: String, val name: String)
    private var categories = listOf(Choice("", "All Categories"))
    private var subcategories = listOf(Choice("", "All Subcategories"))
    private var currentPage = 1
    private var lastPage = 1

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        name = findViewById(R.id.name)
        email = findViewById(R.id.email)
        password = findViewById(R.id.password)
        confirmPassword = findViewById(R.id.password_confirmation)
        loginButton = findViewById(R.id.login)
        registerButton = findViewById(R.id.register)
        panel = findViewById(R.id.panel)
        servicesPanel = findViewById(R.id.servicesPanel)

        categorySpinner = findViewById(R.id.categorySpinner)
        subcategorySpinner = findViewById(R.id.subcategorySpinner)
        serviceSearch = findViewById(R.id.serviceSearch)
        serviceList = findViewById(R.id.serviceList)
        serviceCount = findViewById(R.id.serviceCount)
        nextServices = findViewById(R.id.nextServices)

        contentPanel = LinearLayout(this)
        contentPanel.orientation = LinearLayout.VERTICAL
        contentPanel.setPadding(0, 12, 0, 0)
        panel.addView(contentPanel, 0)

        loginButton.setOnClickListener { login() }
        registerButton.setOnClickListener { if (registerMode) register() else setRegisterMode(true) }

        findViewById<Button>(R.id.dashboard).setOnClickListener { showDashboard() }
        findViewById<Button>(R.id.services).setOnClickListener { openServices() }
        findViewById<Button>(R.id.orders).setOnClickListener { showOrders() }
        findViewById<Button>(R.id.logout).setOnClickListener {
            token = ""
            panel.visibility = View.GONE
            servicesPanel.visibility = View.GONE
            contentPanel.removeAllViews()

            // Show authentication UI again after logout.
            loginButton.visibility = View.VISIBLE
            registerButton.visibility = View.VISIBLE
            name.visibility = View.GONE
            confirmPassword.visibility = View.GONE
            setRegisterMode(false)
            status.text = "Logged out"
        }

        findViewById<Button>(R.id.searchServices).setOnClickListener { loadServices(1) }
        findViewById<Button>(R.id.resetServices).setOnClickListener {
            categorySpinner.setSelection(0)
            serviceSearch.setText("")
            loadSubcategories("")
            loadServices(1)
        }
        nextServices.setOnClickListener {
            if (currentPage < lastPage) loadServices(currentPage + 1)
        }

        categorySpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(
                    parent: AdapterView<*>?, view: View?, position: Int, id: Long
                ) {
                    if (position in categories.indices) {
                        loadSubcategories(categories[position].id)
                    }
                }
            }
    }

    private fun setRegisterMode(enabled: Boolean) {
        registerMode = enabled
        name.visibility = if (enabled) View.VISIBLE else View.GONE
        confirmPassword.visibility = if (enabled) View.VISIBLE else View.GONE
        loginButton.text = if (enabled) "BACK TO LOGIN" else "LOGIN"
        registerButton.text = if (enabled) "CREATE ACCOUNT" else "REGISTER"
        status.text = if (enabled) "Create your TechPremPro account" else "Enter your credentials"
        loginButton.setOnClickListener {
            if (registerMode) setRegisterMode(false) else login()
        }
    }

    private fun login() {
        val e = email.text.toString().trim()
        val p = password.text.toString()
        if (e.isBlank() || p.isBlank()) {
            status.text = "Email and password are required"
            return
        }

        status.text = "Logging in..."
        thread {
            try {
                val body = JSONObject()
                    .put("email", e)
                    .put("password", p)
                    .put("device_name", "TechPremPro Android")

                val res = request("/login", "POST", body.toString(), false)
                val j = JSONObject(res.second)

                runOnUiThread {
                    if (res.first in 200..299 && j.has("token")) {
                        token = j.getString("token")

                        // Hide authentication UI after successful login.
                        name.visibility = View.GONE
                        confirmPassword.visibility = View.GONE
                        loginButton.visibility = View.GONE
                        registerButton.visibility = View.GONE

                        panel.visibility = View.VISIBLE
                        servicesPanel.visibility = View.GONE
                        status.text = "Login successful"
                        showDashboard()
                    } else {
                        status.text = j.optString("message", "Login failed")
                    }
                }
            } catch (x: Exception) {
                runOnUiThread { status.text = x.message ?: "Network error" }
            }
        }
    }

    private fun register() {
        val n = name.text.toString().trim()
        val e = email.text.toString().trim()
        val p = password.text.toString()
        val cp = confirmPassword.text.toString()

        if (n.isBlank() || e.isBlank() || p.isBlank() || cp.isBlank()) {
            status.text = "All fields are required"
            return
        }
        if (p != cp) {
            status.text = "Passwords do not match"
            return
        }
        if (p.length < 8) {
            status.text = "Password must be at least 8 characters"
            return
        }

        status.text = "Creating account..."
        thread {
            try {
                val body = JSONObject()
                    .put("name", n)
                    .put("email", e)
                    .put("password", p)
                    .put("password_confirmation", cp)
                    .put("device_name", "TechPremPro Android")

                val res = request("/register", "POST", body.toString(), false)
                val j = JSONObject(res.second)

                runOnUiThread {
                    if (res.first in 200..299) {
                        setRegisterMode(false)
                        email.setText(e)
                        status.text = j.optString(
                            "message",
                            "Registration successful. Please verify your email, then login."
                        )
                    } else {
                        status.text = j.optString("message", "Registration failed")
                    }
                }
            } catch (x: Exception) {
                runOnUiThread { status.text = x.message ?: "Network error" }
            }
        }
    }

    private fun showDashboard() {
        servicesPanel.visibility = View.GONE
        contentPanel.removeAllViews()
        status.text = "Loading dashboard..."

        thread {
            try {
                val r = request("/dashboard", "GET", null, true)
                val j = JSONObject(r.second)

                runOnUiThread {
                    if (r.first !in 200..299) {
                        status.text = j.optString("message", "Unable to load dashboard")
                        return@runOnUiThread
                    }
                    renderDashboard(j)
                }
            } catch (x: Exception) {
                runOnUiThread { status.text = x.message ?: "Network error" }
            }
        }
    }

    private fun renderDashboard(j: JSONObject) {
        contentPanel.removeAllViews()

        addHeader("Dashboard")
        addBalanceCard("BALANCE", "$" + money(j.optDouble("balance", 0.0)))
        addBalanceCard("REFERRAL BALANCE", "$" + money(j.optDouble("referral_balance", 0.0)))

        val total = j.optInt("total_orders", 0)
        val active = j.optInt("active_orders", 0)
        val completed = j.optInt("completed_orders", 0)

        addStat("TOTAL ORDERS", total.toString())
        addStat("ACTIVE ORDERS", active.toString())
        addStat("COMPLETED ORDERS", completed.toString())

        val tx = j.optJSONArray("transactions")
        if (tx != null && tx.length() > 0) {
            addHeader("Recent Transactions")
            for (i in 0 until minOf(tx.length(), 10)) {
                val o = tx.optJSONObject(i) ?: continue
                addTransactionCard(o)
            }
        }

        status.text = "Dashboard loaded"
    }

    private fun showOrders() {
        servicesPanel.visibility = View.GONE
        contentPanel.removeAllViews()
        status.text = "Loading orders..."

        thread {
            try {
                val r = request("/orders", "GET", null, true)
                val j = JSONObject(r.second)
                runOnUiThread {
                    if (r.first !in 200..299) {
                        status.text = j.optString("message", "Unable to load orders")
                        return@runOnUiThread
                    }
                    renderOrders(j)
                }
            } catch (x: Exception) {
                runOnUiThread { status.text = x.message ?: "Network error" }
            }
        }
    }

    private fun renderOrders(j: JSONObject) {
        contentPanel.removeAllViews()
        addHeader("My Orders")

        val data = when {
            j.optJSONArray("data") != null -> j.optJSONArray("data")
            j.optJSONArray("orders") != null -> j.optJSONArray("orders")
            else -> JSONArray()
        } ?: JSONArray()

        if (data.length() == 0) {
            val empty = TextView(this)
            empty.text = "No orders found"
            empty.textSize = 18f
            empty.setPadding(16, 30, 16, 30)
            contentPanel.addView(empty)
        } else {
            for (i in 0 until data.length()) {
                val o = data.optJSONObject(i) ?: continue
                addOrderCard(o)
            }
        }
        status.text = "Orders loaded"
    }

    private fun addOrderCard(o: JSONObject) {
        val card = card()
        val id = o.optString("id", o.optString("order_id", ""))
        val service = o.optString("service_name",
            o.optJSONObject("service")?.optString("name", "Service") ?: "Service")
        val statusText = o.optString("status", "Pending")
        val qty = o.optString("quantity", "")
        val charge = o.optString("charge", o.optString("price", ""))

        val title = TextView(this)
        title.text = "Order #$id"
        title.textSize = 18f
        title.setTypeface(null, Typeface.BOLD)
        title.setTextColor(Color.rgb(20, 45, 80))
        card.addView(title)

        val info = TextView(this)
        info.text = "$service\nQuantity: $qty\nCharge: $${charge}"
        info.textSize = 14f
        info.setPadding(0, 8, 0, 8)
        card.addView(info)

        val badge = TextView(this)
        badge.text = statusText.uppercase()
        badge.setTypeface(null, Typeface.BOLD)
        badge.setPadding(12, 8, 12, 8)
        badge.setTextColor(Color.WHITE)
        badge.setBackgroundColor(statusColor(statusText))
        card.addView(badge)

        if (statusText.equals("Pending", true)) {
            val cancel = Button(this)
            cancel.text = "CANCEL ORDER"
            cancel.setOnClickListener { cancelOrder(id) }
            card.addView(cancel)
        }
        contentPanel.addView(card)
    }

    private fun cancelOrder(id: String) {
        if (id.isBlank()) return
        status.text = "Canceling order..."
        thread {
            try {
                val r = request("/orders/$id/cancel", "POST", JSONObject().toString(), true)
                val j = JSONObject(r.second)
                runOnUiThread {
                    status.text = if (r.first in 200..299)
                        j.optString("message", "Order canceled successfully")
                    else j.optString("message", "Unable to cancel order")
                    if (r.first in 200..299) showOrders()
                }
            } catch (x: Exception) {
                runOnUiThread { status.text = x.message ?: "Cancel failed" }
            }
        }
    }

    private fun openServices() {
        contentPanel.removeAllViews()
        servicesPanel.visibility = View.VISIBLE
        status.text = "Loading services..."
        loadCategories()
        loadServices(1)
    }

    private fun loadCategories() {
        thread {
            try {
                val r = request("/categories", "GET", null, true)
                val j = JSONObject(r.second)
                val arr = when {
                    j.optJSONArray("data") != null -> j.optJSONArray("data")!!
                    j.optJSONArray("categories") != null -> j.optJSONArray("categories")!!
                    else -> JSONArray()
                }

                val list = mutableListOf(Choice("", "All Categories"))
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    list.add(Choice(o.optString("id"), o.optString("name", "Category")))
                }

                runOnUiThread {
                    categories = list
                    setSpinner(categorySpinner, categories.map { it.name })
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun loadSubcategories(categoryId: String) {
        thread {
            try {
                var path = "/categories"
                if (categoryId.isNotBlank()) {
                    path += "?category_id=" + enc(categoryId)
                }

                val r = request(path, "GET", null, true)
                val j = JSONObject(r.second)
                val arr = when {
                    j.optJSONArray("data") != null -> j.optJSONArray("data")!!
                    j.optJSONArray("subcategories") != null -> j.optJSONArray("subcategories")!!
                    else -> JSONArray()
                }

                val list = mutableListOf(Choice("", "All Subcategories"))

                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val subs = o.optJSONArray("subcategories")
                    if (subs != null) {
                        for (k in 0 until subs.length()) {
                            val s = subs.optJSONObject(k) ?: continue
                            list.add(Choice(s.optString("id"), s.optString("name", "Subcategory")))
                        }
                    } else if (o.has("name") && o.has("id")) {
                        list.add(Choice(o.optString("id"), o.optString("name")))
                    }
                }

                runOnUiThread {
                    subcategories = list.distinctBy { it.id }
                    setSpinner(subcategorySpinner, subcategories.map { it.name })
                }
            } catch (_: Exception) {
                runOnUiThread {
                    subcategories = listOf(Choice("", "All Subcategories"))
                    setSpinner(subcategorySpinner, listOf("All Subcategories"))
                }
            }
        }
    }

    private fun loadServices(page: Int) {
        if (token.isBlank()) return

        currentPage = page
        val cat = if (categorySpinner.selectedItemPosition in categories.indices)
            categories[categorySpinner.selectedItemPosition].id else ""
        val sub = if (subcategorySpinner.selectedItemPosition in subcategories.indices)
            subcategories[subcategorySpinner.selectedItemPosition].id else ""
        val q = serviceSearch.text.toString().trim()

        val params = mutableListOf("page=$page")
        if (cat.isNotBlank()) params.add("category_id=" + enc(cat))
        if (sub.isNotBlank()) params.add("subcategory_id=" + enc(sub))
        if (q.isNotBlank()) params.add("search=" + enc(q))

        status.text = "Loading services..."

        thread {
            try {
                val r = request("/services?" + params.joinToString("&"), "GET", null, true)
                val j = JSONObject(r.second)

                if (r.first !in 200..299) {
                    throw Exception(j.optString("message", "Unable to load services"))
                }

                val data = j.optJSONArray("data") ?: JSONArray()
                val meta = j.optJSONObject("meta")
                lastPage = meta?.optInt("last_page",
                    j.optInt("last_page", 1)) ?: j.optInt("last_page", 1)
                val total = meta?.optInt("total",
                    j.optInt("total", data.length())) ?: j.optInt("total", data.length())

                runOnUiThread { renderServices(data, total) }
            } catch (x: Exception) {
                runOnUiThread {
                    serviceList.removeAllViews()
                    serviceCount.text = ""
                    nextServices.visibility = View.GONE
                    status.text = x.message ?: "Unable to load services"
                }
            }
        }
    }

    private fun renderServices(data: JSONArray, total: Int) {
        serviceList.removeAllViews()
        serviceCount.text =
            "Showing ${data.length()} services • Total $total • Page $currentPage/$lastPage"

        for (i in 0 until data.length()) {
            val o = data.optJSONObject(i) ?: continue
            val card = card()

            val title = TextView(this)
            title.text = "${o.optString("id", "")}  ${o.optString("name", "Service")}".trim()
            title.textSize = 17f
            title.setTypeface(null, Typeface.BOLD)
            title.setTextColor(Color.rgb(20, 45, 80))
            card.addView(title)

            val category = o.optString("category_name",
                o.optJSONObject("category")?.optString("name", "") ?: "")
            val sub = o.optString("subcategory_name",
                o.optJSONObject("subcategory")?.optString("name", "") ?: "")
            val price = o.optString("price", o.optString("rate", "0"))
            val min = o.optString("min", o.optString("min_quantity", ""))
            val max = o.optString("max", o.optString("max_quantity", ""))

            val info = TextView(this)
            info.text =
                "${if (category.isNotBlank()) category else ""}" +
                "${if (sub.isNotBlank()) " • $sub" else ""}\n" +
                "Rate /1000: $$price\nMin: $min   Max: $max"
            info.textSize = 14f
            info.setPadding(0, 8, 0, 8)
            card.addView(info)

            val order = Button(this)
            order.text = "ORDER"
            order.setOnClickListener { showOrderDialog(o) }
            card.addView(order)

            serviceList.addView(card)
        }

        nextServices.visibility =
            if (currentPage < lastPage) View.VISIBLE else View.GONE
        status.text = "Services loaded"
    }

    private fun showOrderDialog(service: JSONObject) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(30, 5, 30, 5)

        val link = EditText(this)
        link.hint = "Link"
        box.addView(link)

        val qty = EditText(this)
        qty.hint = "Quantity"
        qty.inputType = InputType.TYPE_CLASS_NUMBER
        box.addView(qty)

        AlertDialog.Builder(this)
            .setTitle(service.optString("name", "Order Service"))
            .setView(box)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("PLACE ORDER") { _, _ ->
                placeOrder(service, link.text.toString().trim(), qty.text.toString().trim())
            }
            .show()
    }

    private fun placeOrder(service: JSONObject, link: String, quantity: String) {
        if (link.isBlank() || quantity.isBlank()) {
            status.text = "Link and quantity are required"
            return
        }

        val qty = quantity.toIntOrNull()
        if (qty == null || qty <= 0) {
            status.text = "Enter a valid quantity"
            return
        }

        thread {
            try {
                val body = JSONObject()
                    .put("service_id", service.optString("id"))
                    .put("link", link)
                    .put("quantity", qty)

                val r = request("/orders", "POST", body.toString(), true)
                val j = JSONObject(r.second)

                runOnUiThread {
                    status.text = if (r.first in 200..299)
                        j.optString("message", "Order placed successfully")
                    else j.optString("message", "Order failed")
                }
            } catch (x: Exception) {
                runOnUiThread { status.text = x.message ?: "Order failed" }
            }
        }
    }

    private fun addHeader(text: String) {
        val t = TextView(this)
        t.text = text
        t.textSize = 23f
        t.setTypeface(null, Typeface.BOLD)
        t.setTextColor(Color.rgb(20, 45, 80))
        t.setPadding(4, 8, 4, 12)
        contentPanel.addView(t)
    }

    private fun addBalanceCard(label: String, value: String) {
        val card = card()
        val l = TextView(this)
        l.text = label
        l.textSize = 13f
        l.setTypeface(null, Typeface.BOLD)

        val v = TextView(this)
        v.text = value
        v.textSize = 25f
        v.setTypeface(null, Typeface.BOLD)
        v.setTextColor(Color.rgb(20, 130, 70))
        v.setPadding(0, 4, 0, 0)

        card.addView(l)
        card.addView(v)
        contentPanel.addView(card)
    }

    private fun addStat(label: String, value: String) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(8, 10, 8, 10)

        val l = TextView(this)
        l.text = label
        l.textSize = 15f
        l.setTypeface(null, Typeface.BOLD)
        row.addView(l, LinearLayout.LayoutParams(0, -2, 1f))

        val v = TextView(this)
        v.text = value
        v.textSize = 18f
        v.setTypeface(null, Typeface.BOLD)
        row.addView(v)

        contentPanel.addView(row)
    }

    private fun addTransactionCard(o: JSONObject) {
        val c = card()
        val id = TextView(this)
        id.text = o.optString("transaction_id", "Transaction")
        id.setTypeface(null, Typeface.BOLD)

        val amount = o.optString("amount", "0")
        val method = o.optString("payment_method", "Wallet")
        val st = o.optString("status", "")

        val info = TextView(this)
        info.text = "Amount: $amount\nMethod: $method\nStatus: $st"
        info.setPadding(0, 6, 0, 0)

        c.addView(id)
        c.addView(info)
        contentPanel.addView(c)
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(18, 16, 18, 16)
        c.setBackgroundColor(Color.rgb(245, 247, 250))
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(0, 0, 0, 12)
        c.layoutParams = lp
        return c
    }

    private fun statusColor(s: String): Int {
        return when (s.lowercase()) {
            "pending" -> Color.rgb(230, 160, 30)
            "processing" -> Color.rgb(35, 110, 210)
            "completed" -> Color.rgb(30, 150, 80)
            "canceled", "cancelled" -> Color.rgb(210, 55, 55)
            else -> Color.rgb(100, 100, 100)
        }
    }

    private fun setSpinner(spinner: Spinner, items: List<String>) {
        spinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            items
        )
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun money(v: Double): String = String.format("%.4f", v)

    private fun request(
        path: String,
        method: String,
        body: String?,
        auth: Boolean
    ): Pair<Int, String> {
        val c = URL(baseUrl + path).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.setRequestProperty("Accept", "application/json")

        if (auth && token.isNotBlank()) {
            c.setRequestProperty("Authorization", "Bearer $token")
        }

        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
        }

        val code = c.responseCode
        val stream = if (code >= 400) c.errorStream else c.inputStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        c.disconnect()
        return code to text
    }
}
